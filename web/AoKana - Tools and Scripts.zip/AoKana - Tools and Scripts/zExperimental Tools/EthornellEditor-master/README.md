# EthornellEditor 2
Can translate Buriko General Interpeter engine Scripts, don't support BSE scripts (BGI v2)

(Please, if you know about BSE scripts encryption plz send-me information for i add support in my program)
