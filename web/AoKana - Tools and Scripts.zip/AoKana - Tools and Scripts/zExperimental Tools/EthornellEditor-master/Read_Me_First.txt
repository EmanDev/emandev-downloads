To get the compiled EthornellEditor (latest Build)
Open:
EEGUI > bin > choose Debug or Release
from here you will have EEGUI.exe, so just open it.